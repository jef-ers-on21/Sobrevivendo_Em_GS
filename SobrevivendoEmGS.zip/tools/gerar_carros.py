from PIL import Image, ImageDraw, ImageFont
import numpy as np
from scipy import ndimage as ndi
SRC='assets/carros.png'
im=Image.open(SRC).convert('RGB')
a=np.array(im).astype(int)
bg=np.array([39,38,42])
d=np.abs(a-bg).max(axis=2)
# boxes (y0,x0,y1,x1) found by connected components; row 3 cut above labels
boxes=[(155,27,283,272),(157,306,283,567),(142,594,276,892),(131,910,274,1200),(131,1230,276,1519),
(361,19,503,305),(340,326,504,623),(364,636,500,888),(342,923,502,1189),(345,1230,504,1508),
(557,16,728,349),(590,375,726,640),(561,674,724,927),(553,952,735,1201),(553,1232,735,1525),
(798,17,941,311),(788,342,942,598),(781,633,939,901),(785,945,939,1208),(797,1239,942,1517)]
names=["Uno","Gol GTS","Opala","Maverick","Chevrolet D20","Hilux","F-1000","Fusca","Kombi","Sprinter",
"Pickup Blindada","Buggy","Jeep","Trator","Monster Truck","Viatura Policial","Ambulancia","Guincho","Caminhao Militar","Caminhao de Combustivel"]
crops=[]
for (y0,x0,y1,x1) in boxes:
    sub=a[y0:y1,x0:x1]; dd=d[y0:y1,x0:x1]
    m=dd>=14
    lab,n=ndi.label(ndi.binary_dilation(m,iterations=2))
    sizes=ndi.sum(m,lab,range(1,n+1))
    keep=np.zeros_like(m)
    for i,s in enumerate(sizes):
        if s>60: keep|=(lab==i+1)&m
    keep=ndi.binary_fill_holes(ndi.binary_closing(keep,iterations=2))
    ys,xs=np.where(keep)
    ty0,ty1,tx0,tx1=ys.min(),ys.max()+1,xs.min(),xs.max()+1
    rgb=sub[ty0:ty1,tx0:tx1].astype(np.uint8)
    al=(keep[ty0:ty1,tx0:tx1]*255).astype(np.uint8)
    crops.append((rgb,al))
maxw=max(c[0].shape[1] for c in crops); maxh=max(c[0].shape[0] for c in crops)
s=min(128/maxw,64/maxh)
print('maxw',maxw,'maxh',maxh,'scale',s)
CW,CH=128,64
sprites=[]
for (rgb,al),nm in zip(crops,names):
    h,w=al.shape
    nw,nh=max(1,round(w*s)),max(1,round(h*s))
    # premultiply-ish: fill transparent with nearest colour to avoid dark halos
    idx=ndi.distance_transform_edt(al==0,return_distances=False,return_indices=True)
    filled=rgb[idx[0],idx[1]]
    r=Image.fromarray(filled).resize((nw,nh),Image.BOX)
    ra=Image.fromarray(al).resize((nw,nh),Image.BOX)
    canvas=Image.new('RGBA',(CW,CH),(0,0,0,0))
    rr=np.array(r); aa=(np.array(ra)>=128)
    out=np.zeros((nh,nw,4),np.uint8); out[...,:3]=rr; out[...,3]=aa*255
    px=(CW-nw)//2; py=CH-nh-1
    canvas.paste(Image.fromarray(out,'RGBA'),(px,py))
    sprites.append(canvas)
    print(nm,nw,nh)
# contact sheet
sheet=Image.new('RGBA',(5*CW*2,4*CH*2),(255,0,255,255))
for i,sp in enumerate(sprites):
    big=sp.resize((CW*2,CH*2),Image.NEAREST)
    sheet.alpha_composite(big,((i%5)*CW*2,(i//5)*CH*2))
sheet.convert('RGB').save('contact.png')
# header
with open('cars_data.h','w') as f:
    f.write('/* Gerado por tools/gerar_carros.py a partir de assets/carros.png\n   20 sprites 128x64, formato GU_PSM_5551 (A1 B5 G5 R5). */\n')
    f.write('#ifndef CARS_DATA_H\n#define CARS_DATA_H\n#define CAR_TEX_W 128\n#define CAR_TEX_H 64\n#define CAR_COUNT 20\n')
    f.write('static const unsigned short __attribute__((aligned(16))) cars_data[CAR_COUNT][CAR_TEX_W*CAR_TEX_H] = {\n')
    for sp in sprites:
        arr=np.array(sp).astype(np.uint32)
        v=((arr[...,0]>>3)|((arr[...,1]>>3)<<5)|((arr[...,2]>>3)<<10)|((arr[...,3]>=128).astype(np.uint32)<<15)).flatten()
        f.write('{')
        f.write(','.join('0x%04x'%x for x in v))
        f.write('},\n')
    f.write('};\n#endif\n')
# icon
ic=Image.new('RGB',(144,80),(30,30,34))
dr=ImageDraw.Draw(ic)
try:
    ft=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',13)
    ft2=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',16)
except Exception:
    ft=ft2=ImageFont.load_default()
jeep=sprites[12].crop((0,10,128,64)).resize((144,60),Image.NEAREST)
ic.paste(jeep,(0,24),jeep)
dr.rectangle((0,0,143,2),fill=(150,20,20))
dr.text((6,4),'SOBREVIVENDO',font=ft,fill=(230,230,230))
dr.text((6,17),'EM GS',font=ft2,fill=(200,30,30))
ic.save('ICON0.PNG')

